rm -f assignment2.zip
zip -r assignment2.zip * -x '/venv*'
